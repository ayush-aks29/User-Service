package com.userService.controller;

import com.userService.entity.User;
import com.userService.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserService userService;

    //create
    @PostMapping("/addUser")
    public ResponseEntity<User> createuser(@RequestBody User user){
       User createdUser = userService.saveUser(user);
       return ResponseEntity.status(HttpStatus.CREATED).body(createdUser);
    }

    //get user by id
    @GetMapping("/getById/{userId}")
    public ResponseEntity<User> getUserById(@PathVariable Integer userId){
        User user = userService.getUserById(userId);
        return ResponseEntity.ok(user);
    }

    // get all users
    @GetMapping("/getAllUsers")
    public ResponseEntity<List<User>> getAllUsers(){
        List<User> allUsers = userService.getAllUsers();
        return ResponseEntity.ok(allUsers);
    }
}
